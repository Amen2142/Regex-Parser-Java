package PA04;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Parser {
	
	// class variables 
	private Pattern itemPattern;
	private ArrayList<Product> products;
	
	// define the class constructor 
	public Parser(String itemRegex) 
	{
		// create the Pattern object from itemRegex
		itemPattern.compile(itemRegex);
	}// end of the constructor
	
	// reads a text file whose name is given as a parameter
	// and returns the file contents in a string format
	private String getFileContents(String fileName) throws FileNotFoundException {
		// Use the scanner to read the data from the fileName parameter
		File file = new File(fileName);
		Scanner scan = new Scanner(file);
		// create one string input of the file
		String read = "";
		while (scan.hasNextLine())
			read += scan.nextLine();
		// close the scanner
		scan.close();
		// return the string not null
		return read;
	}// end of getFileContent method
	
	// parses a text file whose name is given as a parameter 
	// and returns the parsed products as Product objects stored in an array list
	public ArrayList<Product> parse(String fileName) throws FileNotFoundException {
		// call getFileContent to retrieve the file contents
		String contents = getFileContents(fileName);
		
		// define the Pattern object
		Matcher match = itemPattern.matcher(contents);

		// define ArrayList (products) to be used to hold the Product objects
		products = new ArrayList<Product>();

		// declare a temporary Product object(productObject) 
		Product tempProduct;
		
		try {
			while (match.find())
			{
				tempProduct = new Product(match.group(1), match.group(3));
				products.add(tempProduct);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return products;
	}// end of parse method
}

